Copy the contents of the zip to "D:\Documents\Dolphin Emulator\Load"
The pack comes with the most essential codes for bug testing. You can copy your ctgp mystuff to the My Stuff folder located in the TestingPack folder. It contains:
-Lap&Speed modifier
-A speedometer
-Various informational panels
-An alpha checkpoints/item points display
-Various quality of life codes
You can access various settings and disable/enable some codes by clicking the top right button on the licenses screen and going into settings.

Moreover, the pack comes with the possibility to inject custom ghosts and custom tracks.
Create two folders named Ghosts and Course in "D:\Documents\Dolphin Emulator\Wii"
-Download a ghost file (.rkg) from Chadsoft (or somewhere else). Rename the rkg XX.rkg, where XX can be any number, and paste it in the Ghosts folder.
-Download a track file (.szs), name it depending on which track you want it to replace https://mariokartwii.com/showthread.php?tid=275, and paste it in the Course folder.

If you find any bugs or if the game crashes, DM (or message in a server) Melg (TestUsername#6938) on discord. 